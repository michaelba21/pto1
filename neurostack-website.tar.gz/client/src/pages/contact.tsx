import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Mail, MapPin, Clock, Send, Linkedin, Github } from 'lucide-react';

export default function Contact() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    service: '',
    budget: '',
    message: ''
  });

  const contactMutation = useMutation({
    mutationFn: (data: typeof formData) => 
      apiRequest('POST', '/api/contact', data),
    onSuccess: () => {
      toast({
        title: 'Message sent successfully!',
        description: 'Thank you for your message. I will get back to you within 24 hours.',
      });
      setFormData({
        name: '',
        email: '',
        service: '',
        budget: '',
        message: ''
      });
    },
    onError: (error) => {
      toast({
        title: 'Error sending message',
        description: error.message || 'Please try again later.',
        variant: 'destructive'
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.service || !formData.message) {
      toast({
        title: 'Please fill in all required fields',
        variant: 'destructive'
      });
      return;
    }

    contactMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <>
      <title>Contact - NeuroStack Solutions</title>
      <meta name="description" content="Get in touch with NeuroStack Solutions for your web development, AI automation, and cybersecurity needs. 24-hour response guarantee." />
      
      <div className="pt-16">
        <section className="py-20 bg-gray-50 dark:bg-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center space-y-4 mb-16">
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white">
                Let's Build Something Amazing
              </h1>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Ready to start your project? Get in touch and let's discuss how I can help bring your vision to life.
              </p>
              <div className="w-20 h-1 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full mx-auto"></div>
            </div>

            <div className="grid lg:grid-cols-2 gap-16">
              {/* Contact Form */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl">Send a Message</CardTitle>
                  <CardDescription>
                    Fill out the form below and I'll get back to you within 24 hours.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Name */}
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        placeholder="Your full name"
                        required
                      />
                    </div>

                    {/* Email */}
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        placeholder="your.email@company.com"
                        required
                      />
                    </div>

                    {/* Service Selection */}
                    <div className="space-y-2">
                      <Label htmlFor="service">Service Needed *</Label>
                      <Select value={formData.service} onValueChange={(value) => handleInputChange('service', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a service" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="fullstack">Full-Stack Development</SelectItem>
                          <SelectItem value="api">API Development & Integration</SelectItem>
                          <SelectItem value="security">Cybersecurity Support</SelectItem>
                          <SelectItem value="ai">AI-Powered Automation</SelectItem>
                          <SelectItem value="devops">DevOps & Hosting</SelectItem>
                          <SelectItem value="consultation">Technical Consultation</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Budget Range */}
                    <div className="space-y-2">
                      <Label htmlFor="budget">Budget Range</Label>
                      <Select value={formData.budget} onValueChange={(value) => handleInputChange('budget', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select budget range" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="under-5k">Under €5,000</SelectItem>
                          <SelectItem value="5k-15k">€5,000 - €15,000</SelectItem>
                          <SelectItem value="15k-30k">€15,000 - €30,000</SelectItem>
                          <SelectItem value="30k-plus">€30,000+</SelectItem>
                          <SelectItem value="discuss">Let's discuss</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Message */}
                    <div className="space-y-2">
                      <Label htmlFor="message">Project Details *</Label>
                      <Textarea
                        id="message"
                        value={formData.message}
                        onChange={(e) => handleInputChange('message', e.target.value)}
                        placeholder="Tell me about your project, timeline, and specific requirements..."
                        rows={5}
                        required
                      />
                    </div>

                    {/* Submit Button */}
                    <Button 
                      type="submit" 
                      className="w-full group" 
                      disabled={contactMutation.isPending}
                    >
                      {contactMutation.isPending ? (
                        'Sending...'
                      ) : (
                        <>
                          Let's Build Your Solution Today
                          <Send className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <div className="space-y-8">
                {/* Contact Details */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">Get in Touch</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Email */}
                    <div className="flex items-start space-x-4">
                      <div className="flex items-center justify-center w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-xl">
                        <Mail className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 dark:text-white">Email</h4>
                        <p className="text-gray-600 dark:text-gray-400">hello@neurostack.nl</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">24h response guarantee</p>
                      </div>
                    </div>

                    {/* LinkedIn */}
                    <div className="flex items-start space-x-4">
                      <div className="flex items-center justify-center w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-xl">
                        <Linkedin className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 dark:text-white">LinkedIn</h4>
                        <p className="text-gray-600 dark:text-gray-400">/in/neurostack-solutions</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Professional networking</p>
                      </div>
                    </div>

                    {/* Location */}
                    <div className="flex items-start space-x-4">
                      <div className="flex items-center justify-center w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-xl">
                        <MapPin className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 dark:text-white">Location</h4>
                        <p className="text-gray-600 dark:text-gray-400">Netherlands</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Dutch & English support</p>
                      </div>
                    </div>

                    {/* Availability */}
                    <div className="flex items-start space-x-4">
                      <div className="flex items-center justify-center w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 rounded-xl">
                        <Clock className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 dark:text-white">Availability</h4>
                        <p className="text-gray-600 dark:text-gray-400">Currently accepting new projects</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Start date: Within 1-2 weeks</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Response Promise */}
                <Card className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white border-0">
                  <CardContent className="p-8">
                    <h3 className="text-xl font-bold mb-4">Quick Response Promise</h3>
                    <p className="mb-6 opacity-90">
                      I understand that time is critical for your business. That's why I guarantee a response within 24 hours, often much sooner.
                    </p>
                    <div className="flex items-center space-x-2">
                      <Send className="w-5 h-5 text-yellow-300" />
                      <span className="font-semibold">Fast, reliable, professional service</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Technology Stack Display */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-xl">Technology Stack</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {[
                        { name: 'React', icon: '⚛️' },
                        { name: 'Node.js', icon: '🟢' },
                        { name: 'Python', icon: '🐍' },
                        { name: 'MongoDB', icon: '🍃' },
                        { name: 'OpenAI', icon: '🤖' },
                        { name: 'Security', icon: '🛡️' }
                      ].map((tech) => (
                        <div key={tech.name} className="flex items-center space-x-2 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                          <span className="text-lg">{tech.icon}</span>
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{tech.name}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
